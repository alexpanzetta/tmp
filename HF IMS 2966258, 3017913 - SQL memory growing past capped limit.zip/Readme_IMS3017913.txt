		Hotfix for IMS-3017913 - High SQL Server memory consumption, Historian queries got slower and slower
    		----------------------------------------------------oOo--------------------------------------------------------
		

Resolved Issues:
================
High SQL Server memory consumption, Historian queries got slower and slower



Software Requirements:
======================
Aveva Historian 2020R2SP1P01


Contents
=======

Deliverables included in folders:	File Version
========================		==========
x64:
	aahOleDb.dll		2021.1019.4852.3
	


-----------------------------------------------------------------


Instructions :
===============

1. Shutdown Historian from SMC and stop the SQL server from Windows Services

2. Take a backup of aahOleDb.dll present at following folder

    c:\programfiles(x86)\Wonderware\Historian\x64

3. Extract the attached deliverables and replace at the above path.
	
4. Start SQL server first and then start Historian





