ALTER PROCEDURE dbo.aaInternalMergeSyncQueue
    -- Replication server to merge
    -- sync requests for.
    @ReplicationServerKey INT = NULL,

    -- Maxiumum number of unmerged rows to process.
    -- The actual number processed may be less.
    @MaxRowCount bigint = NULL,

    -- Distance apart in seconds to records
    -- can be and still be merged.
    -- if NULL, 900 seconds (15 minutes) will be used.
    @ToleranceInSeconds INT = NULL,

    -- Indicates which rows should be considered.
    -- Rows with EarliestExecutionTime greater than
    -- this will not be considered for processing.
    -- if NULL, the current time will be used.
    @LimitDateTimeUtc DATETIME2 = NULL,

    -- output, returns 1 if there is no merging left to do
    @MergeComplete BIT = NULL output
AS
BEGIN
    SET NOCOUNT ON;
    SET deadlock_priority low;

    -- Maximum distance allowed in hours
    -- resulted from the merge.
    DECLARE @MaxRangeInHours INT = 24;

    BEGIN TRY

        -- sanitize input

        IF @MaxRowCount IS NULL OR @MaxRowCount < 0
        BEGIN
            SET @MaxRowCount = 2000;
        END;

        IF @ReplicationServerKey IS NULL
        BEGIN
            SET @ReplicationServerKey = 0;
        END

        IF @ToleranceInSeconds IS NULL OR @ToleranceInSeconds < 0
        BEGIN
            SET @ToleranceInSeconds = 900;
        END;

        IF @LimitDateTimeUtc IS NULL
        BEGIN
            SET @LimitDateTimeUtc = Getutcdate();
        END;

        -- initialize output

        SET @MergeComplete = 0;

        -- exit quickly if there is nothing to do

        IF NOT EXISTS (
            SELECT 1
            FROM dbo.ReplicationSyncRequestInfo
            WHERE ExecuteState = 2
                AND ReplicationServerKey = @ReplicationServerKey)
        BEGIN
            SET @MergeComplete = 1;
            RETURN;
        END;

        -- main processing
        BEGIN TRANSACTION;

        -- determine candidates for merge
        --
        -- make sure we only have one row per ReplicationTagEntityKey
        -- to avoid logic errors with multiple updates below
        -- note that we don't try to merge rows in the future
        -- because it may delay processing ofexisting rows

        DECLARE @candidate AS table
        (
            ReplicationSyncRequestKey bigint primary key
        );

        IF @LimitDateTimeUtc IS NULL
        BEGIN
            SET @LimitDateTimeUtc = Getutcdate();
        END;

        INSERT @candidate (ReplicationSyncRequestKey)
        SELECT TOP (@MaxRowCount)
            Min(r.ReplicationSyncRequestKey)
        FROM dbo.ReplicationSyncRequestInfo r
        WHERE
            r.ExecuteState = 2
            AND r.EarliestExecutionDateTimeUtc <= @LimitDateTimeUtc
            AND r.ReplicationServerKey = @ReplicationServerKey

        GROUP BY ReplicationTagEntityKey;

        -- determine which candidates we can merge

        DECLARE @merge AS table
        (
            CandidateRequestKey bigint PRIMARY KEY,
            MergeToRequestKey bigint
        );

        INSERT @merge (CandidateRequestKey, MergeToRequestKey)
        SELECT
            m.ReplicationSyncRequestKey AS MergeFromKey,
            max(n.ReplicationSyncRequestKey) AS MergeToKey
        FROM
            @candidate c
        LEFT JOIN dbo.ReplicationSyncRequest m
            ON c.ReplicationSyncRequestKey = m.ReplicationSyncRequestKey
        LEFT JOIN dbo.ReplicationSyncRequest n
            ON m.ReplicationTagEntityKey = n.ReplicationTagEntityKey
            AND m.RequestVersion = n.RequestVersion
        WHERE
            m.ReplicationSyncRequestKey <> n.ReplicationSyncRequestKey
            AND n.ExecuteState <> 1
            AND
            (
                    m.ModStartDateTimeUtc
                    between n.ModStartDateTimeUtc
                    AND dateadd(second, @ToleranceInSeconds, n.ModEndDateTimeUtc)
                OR
                    m.ModEndDateTimeUtc
                    between dateadd(second, -@ToleranceInSeconds, n.ModStartDateTimeUtc)
                    AND n.ModEndDateTimeUtc
                OR
                    ((m.ModStartDateTimeUtc <= n.ModStartDateTimeUtc)
                    AND (m.ModEndDateTimeUtc >= n.ModEndDateTimeUtc))
                OR
                    ((m.ModStartDateTimeUtc >= n.ModStartDateTimeUtc)
                    AND (m.ModEndDateTimeUtc <= n.ModEndDateTimeUtc))
            )
            AND
            dateadd(hour, @MaxRangeInHours, 
                CASE WHEN m.ModStartDateTimeUtc < n.ModStartDateTimeUtc
                    THEN m.ModStartDateTimeUtc
                    ELSE n.ModStartDateTimeUtc
                END) >
            (CASE WHEN m.ModEndDateTimeUtc > n.ModEndDateTimeUtc
                    THEN m.ModEndDateTimeUtc
                    ELSE n.ModEndDateTimeUtc
                    END)
        GROUP BY m.ReplicationSyncRequestKey;

        -- mark the rows we're processing as done

        UPDATE r
            SET ExecuteState = 0
            FROM dbo.ReplicationSyncRequest r
            INNER JOIN @candidate c
                ON r.ReplicationSyncRequestKey = c.ReplicationSyncRequestKey;

        -- update merge targets

        UPDATE r SET
            r.ModStartDateTimeUtc =
                CASE WHEN l.ModStartDateTimeUtc < r.ModStartDateTimeUtc
                    THEN l.ModStartDateTimeUtc
                    ELSE r.ModStartDateTimeUtc
                END,
            r.ModEndDateTimeUtc =
                CASE WHEN l.ModEndDateTimeUtc > r.ModEndDateTimeUtc
                    THEN l.ModEndDateTimeUtc
                    ELSE r.ModEndDateTimeUtc
                END,
            r.EarliestExecutionDateTimeUtc =
                CASE WHEN l.EarliestExecutionDateTimeUtc > r.EarliestExecutionDateTimeUtc
                    THEN l.EarliestExecutionDateTimeUtc
                    ELSE r.EarliestExecutionDateTimeUtc
                END,
            r.ExecuteState = 2
        FROM dbo.ReplicationSyncRequest l
        INNER JOIN @merge m
            ON l.ReplicationSyncRequestKey = m.CandidateRequestKey
        INNER JOIN ReplicationSyncRequest r
            ON m.MergeToRequestKey = r.ReplicationSyncRequestKey;

        -- remove merged rows

        DELETE r
        FROM dbo.ReplicationSyncRequest r
        INNER JOIN @merge m
            ON r.ReplicationSyncRequestKey = m.CandidateRequestKey;

        COMMIT TRANSACTION;

        -- calculate if we are done
        IF NOT EXISTS (

            SELECT 1
            FROM dbo.ReplicationSyncRequestInfo r
            WHERE
                r.ExecuteState = 2
                AND r.EarliestExecutionDateTimeUtc <= @LimitDateTimeUtc
                AND r.ReplicationServerKey = @ReplicationServerKey)

        BEGIN
            SET @MergeComplete = 1;
        END;

        RETURN;
    END TRY
    BEGIN CATCH
        -- Check error number.
        -- If deadlock victim error,
        -- Then simply return as not done
        IF (error_number() = 1205)
        BEGIN
            PRINT 'Aborting due to a deadlock'; -- debugging code only
        END
        ELSE
        BEGIN
            SELECT error_number() AS ErrorNumber ,error_message() AS ErrorMessage; -- rethrow IF not a deadlock
        END;

        IF xact_state() <> 0
            ROLLBACK TRANSACTION;
    END CATCH;

END;
GO
