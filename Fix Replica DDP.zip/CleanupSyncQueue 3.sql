-- Eliminate duplicates

Use Runtime;

DECLARE @ReplicationSync TABLE(
                ReplicationTagEntityKey INT NOT NULL,
                RequestVersion smallint NOT NULL,
                ModStartDateTimeUtc datetime2 NOT NULL,
                ModEndDateTimeUtc datetime2 NOT NULL
)
 
INSERT INTO @ReplicationSync
SELECT 
DISTINCT ReplicationTagEntityKey, RequestVersion, ModStartDateTimeUtc, ModEndDateTimeUtc 
FROM ReplicationSyncRequest
 
DELETE FROM ReplicationSyncRequest
 
INSERT INTO dbo.ReplicationSyncRequest(
                ReplicationTagEntityKey,
    RequestVersion,
    ModStartDateTimeUtc,
    ModEndDateTimeUtc,
    EarliestExecutionDateTimeUtc,
   ExecuteState)
SELECT
                ReplicationTagEntityKey,
                RequestVersion,
                ModStartDateTimeUtc,
                ModEndDateTimeUtc,
                GETUTCDATE(),
                0
FROM @ReplicationSync

-- Break long sync. queue items to 24-hour chunk
DECLARE @ItemsToBreak TABLE(
    ReplicationSyncRequestKey bigint NOT NULL
)

DECLARE syncItemsToBreak CURSOR FOR
	SELECT * from @ItemsToBreak

INSERT INTO @ItemsToBreak
SELECT ReplicationSyncRequestKey
FROM ReplicationSyncRequest WHERE ModEndDateTimeUtc > dateadd(hour, 24, ModStartDateTimeUtc)

DECLARE @replicationSyncRequestKey bigint;
DECLARE @replicationTagEntityKey int;
DECLARE @requestVersion smallint;
DECLARE @modStartDateTimeUtc datetime2;
DECLARE @modEndDateTimeUtc datetime2;
DECLARE @earliestExecutionDateTimeUtc datetime2;
DECLARE @executeState smallint;
DECLARE @outReplicationSyncRequestKey bigint = 0;

WHILE EXISTS(SELECT 1 FROM @ItemsToBreak)
BEGIN
	OPEN syncItemsToBreak;
	FETCH NEXT FROM syncItemsToBreak INTO @replicationSyncRequestKey;

	WHILE @@FETCH_STATUS = 0
	BEGIN
		SELECT @replicationTagEntityKey = a.ReplicationTagEntityKey, @requestVersion = a.RequestVersion, @modStartDateTimeUtc = a.ModStartDateTimeUtc, @modEndDateTimeUtc = dateadd(hour, 24, ModStartDateTimeUtc), 
			@earliestExecutionDateTimeUtc = a.EarliestExecutionDateTimeUtc
		FROM ReplicationSyncRequest a
		WHERE a.ReplicationSyncRequestKey = @replicationSyncRequestKey

		SET @outReplicationSyncRequestKey = 0;
		EXEC dbo.aaInternalReplicationSyncRequestAdd @ReplicationTagEntityKey=@replicationTagEntityKey, @RequestVersion = @requestVersion, @ModStartDateTimeUtc = @modStartDateTimeUtc,
			@ModEndDateTimeUtc=@modEndDateTimeUtc, @EarliestExecutionDateTimeUtc = @earliestExecutionDateTimeUtc, @ExecuteState = 0, @ReplicationSyncRequestKey = @outReplicationSyncRequestKey;

		UPDATE ReplicationSyncRequest
		SET ModStartDateTimeUtc = @modEndDateTimeUtc
		WHERE ReplicationSyncRequestKey = @replicationSyncRequestKey;

		FETCH NEXT FROM syncItemsToBreak INTO @replicationSyncRequestKey;
	END;
	CLOSE syncItemsToBreak;

	DELETE FROM @ItemsToBreak;

	INSERT INTO @ItemsToBreak
	SELECT ReplicationSyncRequestKey
	FROM ReplicationSyncRequest WHERE ModEndDateTimeUtc > dateadd(hour, 24, ModStartDateTimeUtc);
END;

DEALLOCATE syncItemsToBreak;
