		            			 Hotfix for IMS Request 3454758
    						----------------oOo------------------
		

Resolved Issues:
================
IMS Request 3454758: ReplicationSyncRequests stuck when running backfill utility,



Software Requirements:
======================
Aveva Historian 2023 P03, 2023 P04


Contents
=======

Deliverables 						File Version
=============						==========
aahReplication.exe					2022.726.4848.16
	


-----------------------------------------------------------------
Instructions :
===============

1. Shutdown Historian
2. Take a backup of aahReplication.exe located at
	C:\programfiles(x86)\Wonderware\Historian\x64
3. Replace the file with one from attached HF
4. Start Historian