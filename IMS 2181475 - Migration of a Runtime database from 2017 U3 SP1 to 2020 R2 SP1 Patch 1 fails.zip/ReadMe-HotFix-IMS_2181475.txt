		AVEVA Historian 2020R2SP1P01 HF IMS 2181475 Installation Instructions
    		---------------------------------------oOo-------------------------------------
Issue: Migration of a Runtime database from 2017 U3 SP1 to 2020 R2 SP1 Patch 1 fails.


Software Requirements:
======================
Historian 2020R2SP1P01



Deliverables:			File Version
===================		================

aahConfiguratorPlugin.dll	2021.1019.4446.3	
	

Installation Instructions:
================================================

1. Make a backup of the files located under

     On 64-bit OS "[RootDrive]:\Program Files (x86)\Wonderware\Historian\"

2. Copy "aahConfiguratorPlugin.dll" to the path mentioned above and click confirm to replace the file.

3. Launch Configurator and click Configure to migrate the Database.

 
