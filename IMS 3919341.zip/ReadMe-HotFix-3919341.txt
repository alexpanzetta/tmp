Aveva System Platform 2020 R2 SP1 P01 Hot Fix 3919341 Installation Instructions
===============================================================================

Issue
=====
IMS Request 3919341: Port IMS 3467530:InTouch.OPCUA.ServiceHost.exe memory leak issue when writing to tags from OPC UA Client to 2020 R2 SP1 P01

Software Requirements
=====================
Aveva System Platform 2020 R2 SP1 P01

----------------------------------------------------------------------------------------------------

Contents
========
* Ensure after extracting "HF-3919341.exe" , the following hot fix deliverables are copied to the extracted location

        Default Extracted Location
        --------------------------
        Pre Vista OS - [Root Drive]:\Documents and Settings\All Users\Documents\AVEVA\HF-3919341
        Vista and later OS - [Root Drive]:\Users\Public\Documents\AVEVA\HF-3919341
        or [Root Drive]:\Users\Public\Public Documents\AVEVA\HF-3919341

Deliverables                                       File Version        
------------                                       ------------        
DataService.dll                                    2021.1020.5903.1     
InTouch.OPCUA.ServiceHost.exe                      2021.1020.5903.3     
OPCDataSource.dll                                  2021.1020.5903.3     
InstallHotfix.exe                                  2020.1202.3623.3     


Installation Instructions
=========================
Note : On 64-bit OS the Program Files path will be "[RootDrive:]\Program Files (x86)\". On 32-bit OS the Program Files path will be "[RootDrive:]\Program Files\".

1. Execute "HF-3919341.exe" to extract Hot Fix deliverables.
   Hot Fix deliverables will be copied to the location: "[Root Drive]:\Users\Public\Documents\AVEVA\HF-3919341"

2. Ensure that there are 4 files at the location "[Root Drive]:\Users\Public\Documents\AVEVA\HF-3919341"
   a.DataService.dll
   b.InTouch.OPCUA.ServiceHost.exe
   c.OPCDataSource.dll
   d.InstallHotfix.exe

3. Close all Aveva HMI products including WindowMaker, WindowViewer, System Platform IDE, Object Viewer, OMI Runtime and SMC if they are running.

4. Stop InTouchDataService window services.

	a)For Stopping InTouchDataService Window Service.
		> Open Windows TaskManager in machine where product was installed.
		> Navigate to Services tab then select InTouchDataService Windows Service. 
		> Right click on selected InTouchDataService Windows Service and choose Stop option.

5. Take a backup of the files "DataService.dll", "InTouch.OPCUA.ServiceHost.exe" and "OPCDataSource.dll" existing in "[<root drive>]:\Program Files (x86)\Common Files\ArchestrA\Services\InTouchOPCUAService".

6. Take a backup of the file "DataService.dll" existing in "[<root drive>]:\Program Files (x86)\Common Files\ArchestrA\Services\InTouchDataService".
	
7. Complete HF installation by following the instructions on the HF Manager dialog and replace the files "DataService.dll", "InTouch.OPCUA.ServiceHost.exe" and "OPCDataSource.dll" with the one provided with hot fix at the location specified in step 5 and 6.

8. Click on "Yes" button(s) to complete the installation. The Hotfix Manager tool will write the information of the Hot Fix to "<RootDrive>:\ProgramData\AVEVA\Hotfixes\HFDB.xml".

9. Now Start InTouchDataService window services
	a)For Starting InTouchDataService Window Service.
		> Open Windows TaskManager in machine where product was installed.
		> Navigate to Services tab then select InTouchDataService Windows Service. 
		> Right click on selected InTouchDataService Windows Service and choose Start option.

10. Start "System Platform IDE", "WindowMaker" and "WindowViewer".

Previous List of Hot fixes included in this current fix
========================================================
N/A

Other brief details
===================
* Backup merely involves copying the files to another location. Do not rename the files in the same location.

* Machine does not have to be rebooted.

* You can view HotFix information installed on the machine by executing HotFixViewer.exe located at:
[<root drive>]:\Program Files (x86)\AVEVA\HotfixViewer.

Copyright notice
================
� 2025 AVEVA Group Limited and its subsidiaries. All rights reserved.
Refer to: https://sw.aveva.com/legal/trademarks
