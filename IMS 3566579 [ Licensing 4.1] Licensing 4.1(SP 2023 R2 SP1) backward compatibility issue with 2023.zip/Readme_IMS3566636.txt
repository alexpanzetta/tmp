		Hotfix for IMS Request 3566579: [ Licensing 4.1] Licensing 4.1(SP 2023 R2 SP1) backward compatibility issue with SP  2023 Historian
    		----------------------------------------------------oOo------------------
		

Resolved Issues:
================
Licensing 4.1(SP 2023 R2 SP1) backward compatibility issue with SP 2023 Historian 



Software Requirements:
======================
SP 2023 Historian


Contents
========

Deliverables included in folders:			File Version
=================================			============
System.Diagnostics.DiagnosticSource.dll			8.0.424.16909


-----------------------------------------------------------------

Note: Apply the HotFix only if user is upgrading the Licensing Platform to AVEVA Enterprise Licensing Platform 4.1.



Instructions to apply HotFix:
============================

1. Shutdown Historian from SMC.

2. Take a backup of System.Diagnostics.DiagnosticSource.dll present at following folder

    		C:\Program Files (x86)\Wonderware\Historian

3. Copy the provided Hotfix deliverables to C:\Program Files (x86)\Wonderware\Historian.
	
4. Start Historian.





