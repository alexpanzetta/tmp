		Wonderware Historian 2020 Hotfix for IMS1109704 - Replication sync. queue item issue
		Re-released on 8/3/2021
    		------------------------------------------oOo---------------------------------------

Resolved Issues:
================
1064329 - Main Replication Failed to get Sync Requests for Replication Server Key =2, [Invalid Value.Transaction (Process ID xx) was deadlocked on lock resources with another process and has been chosen as the deadlock]


Software Requirements:
======================
System platform 2020 installed.


Contents
=======

Deliverables included in folders:	File Version
========================		==========
x64
	aahReplication.exe		2021.731.3133.3

CleanupSyncQueue.sql - SQL script to eliminate duplicate sync queue entries
UpdateSP.sql - SQL script to update store procedure for merging

-----------------------------------------------------------------


Installation Instructions on Wonderware Application Server Platform node:
=========================================================================


BACKUP:
------------

1. Make a backup of the files "aahReplication.exe" from the following installation path
     On 64-bit OS "[RootDrive]:\Program Files (x86)\Wonderware\Historian\x64"

2. Backup Runtime database because we need to update one of the stored procedures.


REPLACING EXEs and EXECUTING SQL scripts:
------------------------------------------------------------------------------

1. From Historian Management Console:
   Status, All Tasks, Shutdown (and disable) Historian

2. Replcace "aahReplication.exe" at the following installation path
     On 64-bit OS Copy the above files from Win32 to "[RootDrive]:\Program Files (x86)\Wonderware\Historian" and
                  Copy the above files from x64 to "[RootDrive]:\Program Files (x86)\Wonderware\Historian\x64"

3. Start Microsoft SQL Server Management Studio and perform the following steps:
	a. Open a new query editor window for Runtime database: Click the "New Query" icon and select the database to "Runtime"
	b. From menu item File, Open, File..., open file CleanupSyncQueue.sql
	c. Execute the script "CleanupSynQueue.sql"
	d. Repeat steps b-c for script "UpdateSP.sql"

3. Restart Historian

Other brief details:
====================
*  Backup merely involves copying the files to a safe location. Do not rename the files in the same location.
*  Machine reboot is not required.
