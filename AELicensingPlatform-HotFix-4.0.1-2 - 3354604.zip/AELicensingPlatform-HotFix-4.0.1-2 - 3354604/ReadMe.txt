AVEVA Enterprise Licensing Platform 4.0.1 HotFix- Fix for 3002356, 2918166 and 3354604/3201980
======================================================================================

Resolved Issues:
===============

Issues:
=====
3002356 - [CITECT ANYWHERE] client does not release the license in AEL
2918166 - AVEVA Enterprise License Product Service not running with virtual account.
3354604/3201980 - License not acquired OMI application in demo mode.

Solutions:
========
3002356 - Registered Process for exit event
2918166 - While loading the certificate used Machine key set.
3354604/3201980 - Handled concurrency between calls from same process and ignored the duplicate features within the request.

Software Requirements:
=====================
AVEVA Enterprise Licensing Platform 4.0.1

=========================================================================================================
Contents
=================
Ensure after extracting "AELicensingPlatform-HotFix-4.0.1-2" the following hot fix deliverables are copied to the extracted location.
  
Default Extracted Location:
==========================
Pre Vista OS - [Root Drive]:\Documents and Settings\All Users\Documents\AVEVA\AELicensingPlatform-HotFix-4.0.1-2
Vista and later OS - [Root Drive]:\Users\Public\Documents\AVEVA\AELicensingPlatform-HotFix-4.0.1-2


Deliverables:						File Version                           
============						============
ProductLicenseServicegRPC.dll		2023.1215.5622.1
ProductLicenseServicegRPC.exe		2023.1215.5622.1
LicAPISvc.dll						2023.1215.5622.1
LicAPISvcProxy.Core.dll				2023.1215.5622.1
LicAPISvcProxy.NET.dll				2023.1215.5622.1
LicAPISvcProxy.Core-x86.dll			2023.1215.5622.1
LicAPISvcProxy.NET-x86.dll			2023.1215.5622.1


Instructions:
============

1. Run the "AELicensingPlatform-HotFix-4.0.1-2.exe as an Administrator.
2. Click "Next" in Hotfix Description Page.
3. Select "I accept the License Agreement" radio button in License AgreeMent Page and click "Next"
4. By default destination folder is set as "C:\Users\Public\Documents\AVEVA".browse to different folder if extraction is required in different location.
5. click "Extract" button in Extraction Page.
6. Installation of Hotfix on the same Node.
   a.Select check box "Launch the hotfix installable" and click "Extract" button. This will start hotfix installation on this Node.
   b.Click on "Install" button to install hotfix.
7. Installation of Hotfix on a different Node.
   a.Unselect "Launch the hotfix installable" check box  and select "Open Extracted Folder" check box then Click "Extract" button.
   b.Extracted Folder gets Opend with all the extracted files.
   c.Copy the Exctracted Files on the Node where hotfix is required to install.
   c.Run "Installhotfix.exe" as Administrator.
   d.Click on "Install" button to install hotfix .


